from teacher import Teacher

teacher = Teacher()

print(teacher.teach())
print(teacher.get_fired())
print(teacher.sleep())