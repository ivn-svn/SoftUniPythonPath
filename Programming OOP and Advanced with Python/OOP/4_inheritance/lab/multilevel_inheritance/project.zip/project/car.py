from vehicle import Vehicle

class Car:
    def drive(self):
        return "driving..."
