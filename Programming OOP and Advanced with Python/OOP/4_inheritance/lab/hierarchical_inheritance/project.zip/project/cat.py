from animal import Animal

class Cat(animal): 
    def meow(self):
        return "meowing..."