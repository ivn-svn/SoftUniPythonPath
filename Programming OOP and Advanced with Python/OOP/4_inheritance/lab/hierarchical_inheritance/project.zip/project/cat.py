from project.animal import Animal


class Cat(Animal):
    def meow(self):
        return "meowing..."
