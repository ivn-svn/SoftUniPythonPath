from animal import Animal

class Dog(animal): 
    def bark(self):
        return "barking..."