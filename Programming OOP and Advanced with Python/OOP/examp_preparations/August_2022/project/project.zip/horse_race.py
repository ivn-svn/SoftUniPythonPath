from project.jockey import Jockey

class HorseRace:
    VALID_RACE_TYPES = {"Winter", "Spring", "Autumn", "Summer"}

    def __init__(self, race_type: str):
        if race_type not in self.VALID_RACE_TYPES:
            raise ValueError("Race type does not exist!")
        self.race_type = race_type
        self.jockeys = []

    def add_jockey(self, jockey: Jockey):
        self.jockeys.append(jockey)
