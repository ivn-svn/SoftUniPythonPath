from project.horse_specification.horse import Horse
class Appaloosa(Horse):
    MAX_SPEED = 120

    def max_speed(self):
        return Appaloosa.MAX_SPEED

    def training_boost(self):
        return super().training_boost() + 5
