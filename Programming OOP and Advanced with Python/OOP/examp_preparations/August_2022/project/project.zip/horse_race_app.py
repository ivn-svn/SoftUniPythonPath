from project.horse_specification.appaloosa import Appaloosa
from project.horse_specification.thoroughbred import Thoroughbred
from project.horse_specification.horse import Horse
from project.jockey import Jockey
from project.horse_race import HorseRace


class HorseRaceApp:
    def __init__(self):
        self.horses = []
        self.jockeys = []
        self.horse_races = []

    def add_horse(self, horse_type: str, horse_name: str, horse_speed: int) -> str:
        if horse_name in [h.name for h in self.horses]:
            raise Exception(f"Horse {horse_name} has been already added!")

        if horse_type == "Appaloosa":
            horse = Appaloosa(horse_name, horse_speed)
        elif horse_type == "Thoroughbred":
            horse = Thoroughbred(horse_name, horse_speed)
        else:
            return

        self.horses.append(horse)
        return f"{horse_type} horse {horse_name} is added."

    def add_jockey(self, jockey_name: str, age: int) -> str:
        if jockey_name in [j.name for j in self.jockeys]:
            raise Exception(f"Jockey {jockey_name} has been already added!")

        jockey = Jockey(jockey_name, age)
        self.jockeys.append(jockey)
        return f"Jockey {jockey_name} is added."

    def create_horse_race(self, race_type: str) -> str:
        if race_type not in ["Winter", "Spring", "Autumn", "Summer"]:
            raise ValueError("Race type does not exist!")

        for hr in self.horse_races:
            if hr.race_type == race_type:
                raise Exception(f"Race {race_type} has been already created!")

        horse_race = HorseRace(race_type)
        self.horse_races.append(horse_race)
        return f"Race {race_type} is created."

    def add_horse_to_jockey(self, jockey_name: str, horse_type: str) -> str:
        jockey = next((j for j in self.jockeys if j.name == jockey_name), None)
        if jockey is None:
            raise Exception(f"Jockey {jockey_name} could not be found!")

        available_horses = [h for h in self.horses if h.__class__.__name__ == horse_type and h.jockey is None]
        if not available_horses:
            raise Exception(f"Horse breed {horse_type} could not be found!")

        if jockey.horse is not None:
            return f"Jockey {jockey_name} already has a horse."

        horse = available_horses[-1]
        horse.jockey = jockey
        jockey.horse = horse
        return f"Jockey {jockey_name} will ride the horse {horse.name}."

    def add_jockey_to_horse_race(self, race_type: str, jockey_name: str):
        horse_race = next((race for race in self.horse_races if race.race_type == race_type), None)
        if horse_race is None:
            raise Exception(f"Race {race_type} could not be found!")

        jockey = next((j for j in self.jockeys if j.name == jockey_name), None)
        if jockey.horse is None:
            raise Exception(f"Jockey {jockey_name} cannot race without a horse!")

        if jockey in horse_race.jockeys:
            return f"Jockey {jockey_name} has been already added to the {race_type} race."

        horse_race.add_jockey(jockey)
        return f"Jockey {jockey_name} added to the {race_type} race."

    def start_horse_race(self, race_type: str) -> str:
        horse_race = next((race for race in self.horse_races if race.race_type == race_type), None)
        if horse_race is None:
            raise Exception(f"Race {race_type} could not be found!")

        if len(horse_race.jockeys) == 0:
            raise Exception("There are no jockeys in this race.")

        winner = max(horse_race.jockeys, key=lambda jockey: jockey.horse.speed)
        return f"The winner of the {race_type} race, with a speed of {winner.horse.speed}km/h is {winner.name}! Winner's horse: {winner.horse.name}."
