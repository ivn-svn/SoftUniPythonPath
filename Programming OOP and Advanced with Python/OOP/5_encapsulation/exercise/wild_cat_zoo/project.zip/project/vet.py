from project.worker import Worker


class Vet(Worker):

    def __init__(self):
        super().__init__(self)


